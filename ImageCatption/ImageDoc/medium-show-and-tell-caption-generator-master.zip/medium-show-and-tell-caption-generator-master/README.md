# medium-show-and-tell-caption-generator
Code to run inference on a Show And Tell Model. This model is trained to generate captions given an image.

A tutorial for the code can be found here: https://medium.freecodecamp.org/building-an-image-caption-generator-with-deep-learning-in-tensorflow-a142722e9b1f
